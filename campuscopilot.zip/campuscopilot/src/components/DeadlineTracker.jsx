export default function DeadlineTracker() {
    return (
      <div className="deadline-tracker">
        <h2>⏰ Assignment Deadlines</h2>
        <p>This will track your deadlines</p>
      </div>
    )
  }