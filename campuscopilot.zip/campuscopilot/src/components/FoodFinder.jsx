export default function FoodFinder() {
    return (
      <div className="food-finder">
        <h2>🍔 Campus Food Finder</h2>
        <p>This will show nearby food spots</p>
      </div>
    )
  }